#
# Example shell file for starting ./PhoenixMiner to mine ETH
#

# IMPORTANT: Replace the ETH address with your own ETH wallet address in the -wal option (Rig001 is the name of the rig)
./PhoenixMiner -pool ssl://eu1.ethermine.org:5555 -wal 0x39e987c72d3b35da03ba9aca26a9e9f91c16c04c.Rig001
